<?php
 class DBSettings{
 	const DBHOST = "localhost";
	const DBPASSWORD = "root";
	const DBUSER = "root";
	const DATABASE = "Scrum";
	//const DBTABLEPREFIX = "members_";	
 }
?>